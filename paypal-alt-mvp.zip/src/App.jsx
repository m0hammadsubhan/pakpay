import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { useState } from "react";

export default function App() {
  const [email, setEmail] = useState("");
  const [amount, setAmount] = useState("");
  const [paymentLink, setPaymentLink] = useState("");

  const generateLink = () => {
    if (!email || !amount) return alert("Please fill both fields");
    const link = `https://paypal.me/${email.split("@")[0]}/${amount}`;
    setPaymentLink(link);
  };

  return (
    <div className="min-h-screen bg-gray-100 flex flex-col items-center justify-center p-4">
      <Card className="w-full max-w-md p-6 shadow-xl rounded-2xl">
        <CardContent>
          <h1 className="text-2xl font-bold mb-4 text-center">Global Payment Receiver</h1>
          <Input
            type="email"
            placeholder="Enter your PayPal email"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            className="mb-4"
          />
          <Input
            type="number"
            placeholder="Amount to Receive (USD)"
            value={amount}
            onChange={(e) => setAmount(e.target.value)}
            className="mb-4"
          />
          <Button onClick={generateLink} className="w-full">Generate Pay Link</Button>

          {paymentLink && (
            <div className="mt-6 bg-white p-4 rounded-xl shadow-inner text-center">
              <p className="text-gray-600 mb-2">Send this to your client:</p>
              <a
                href={paymentLink}
                target="_blank"
                rel="noopener noreferrer"
                className="text-blue-600 font-medium underline break-all"
              >
                {paymentLink}
              </a>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
